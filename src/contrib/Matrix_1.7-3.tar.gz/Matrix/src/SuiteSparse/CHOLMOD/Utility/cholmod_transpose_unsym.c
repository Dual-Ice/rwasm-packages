//------------------------------------------------------------------------------
// CHOLMOD/Utility/cholmod_transpose_unsym: unsymmetric permuted transpose
//------------------------------------------------------------------------------

// CHOLMOD/Utility Module. Copyright (C) 2023, Timothy A. Davis, All Rights
// Reserved.
// SPDX-License-Identifier: LGPL-2.1+

//------------------------------------------------------------------------------

#define CHOLMOD_INT32
#include "t_cholmod_transpose_unsym.c"

