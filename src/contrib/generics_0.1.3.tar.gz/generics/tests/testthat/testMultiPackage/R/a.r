#' Test data frame
#'
#' @param x,y A parameter
#'
#' @rdname multi-method-4
multi_method.matrix <- function(x, y) {
  x
}
