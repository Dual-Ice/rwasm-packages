library(testthat)
library(generics)

test_check("generics")
