# Guides ---------------------------------------------------------------

#' `r title("topic_error_call")`
#'
#' ```{r, child = "man/rmd/topic-error-call.Rmd"}
#' ```
#'
#' @keywords internal
#' @name topic-error-call
NULL

#' `r title("topic_error_chaining")`
#'
#' ```{r, child = "man/rmd/topic-error-chaining.Rmd"}
#' ```
#'
#' @keywords internal
#' @name topic-error-chaining
NULL


# Notes -------------------------------------------------------------------

#' `r title("topic_condition_formatting")`
#'
#' ```{r, child = "man/rmd/topic-condition-formatting.Rmd"}
#' ```
#'
#' @keywords internal
#' @name topic-condition-formatting
NULL

#' `r title("topic_condition_customisation")`
#'
#' ```{r, child = "man/rmd/topic-condition-customisation.Rmd"}
#' ```
#'
#' @keywords internal
#' @name topic-condition-customisation
NULL
