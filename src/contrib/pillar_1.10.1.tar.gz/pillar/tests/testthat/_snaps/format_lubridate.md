# can output durations

    Code
      pillar(lubridate::as.duration(1:3))
    Output
      <pillar>
      <Duration>
      1s        
      2s        
      3s        

