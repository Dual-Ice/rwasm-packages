# expansion() checks input

    `mult` and `add` must be numeric vectors with 1 or 2 elements.

---

    `mult` and `add` must be numeric vectors with 1 or 2 elements.

