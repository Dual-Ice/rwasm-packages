# geom_ribbon() checks the aesthetics

    Problem while setting up geom.
    i Error occurred in the 1st layer.
    Caused by error in `setup_data()`:
    ! Either xmin or xmax must be given as an aesthetic.

---

    Problem while setting up geom.
    i Error occurred in the 1st layer.
    Caused by error in `setup_data()`:
    ! Either ymin or ymax must be given as an aesthetic.

---

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_group()`:
    ! Aesthetics can not vary along a ribbon.

---

    `outline.type` must be one of "both", "upper", "lower", or "full", not "test".

