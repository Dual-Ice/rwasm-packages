# Coord errors on missing methods

    `coord()` has not implemented a `render_bg()` method.

---

    `coord()` has not implemented a `render_axis_h()` method.

---

    `coord()` has not implemented a `render_axis_v()` method.

---

    `coord()` has not implemented a `backtransform_range()` method.

---

    `coord()` has not implemented a `range()` method.

