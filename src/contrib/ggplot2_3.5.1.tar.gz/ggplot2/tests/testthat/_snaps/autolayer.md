# autolayers default error looks correct

    No autolayer method available for <character> objects.

