# input checks work in compat functions

    Can only remove rownames from <data.frame> and <matrix> objects.

---

    `x` must be a factor or character vector, not an integer vector.

---

    Must be a character vector, call, or formula.

---

    `x` must be a <numeric> vector, not a character vector.

