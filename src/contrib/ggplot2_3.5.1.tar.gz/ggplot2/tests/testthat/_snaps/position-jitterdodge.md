# position_jitterdodge() fails with meaningful error

    Problem while computing position.
    i Error occurred in the 1st layer.
    Caused by error in `setup_params()`:
    ! `position_jitterdodge()` requires at least one aesthetic to dodge by.
    i Use one of "fill", "colour", "linetype", "shape", "size", or "alpha" aesthetics.

