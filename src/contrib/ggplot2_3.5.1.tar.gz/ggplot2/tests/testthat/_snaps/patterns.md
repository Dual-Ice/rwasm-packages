# fill_alpha works as expected

    fill must be a vector of colours or list of <GridPattern> objects.

---

    fill must be a vector of colours or list of <GridPattern> objects.

