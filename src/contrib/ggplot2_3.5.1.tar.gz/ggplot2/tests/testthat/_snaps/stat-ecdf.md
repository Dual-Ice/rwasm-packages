# stat_ecdf works in both directions

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `setup_params()`:
    ! `stat_ecdf()` requires an x or y aesthetic.

